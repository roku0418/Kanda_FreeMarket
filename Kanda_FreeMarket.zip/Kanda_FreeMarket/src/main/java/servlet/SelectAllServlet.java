package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Goods;
import common.Tags;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/selectall")
public class SelectAllServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";
//		String goodsname = request.getParameter("goodsname");
//		String selectedtag = request.getParameter("tags");
//		String[] inputtags = request.getParameterValues("tags");
		int authority = Integer.parseInt(request.getParameter("authority"));
		Tags tags = new Tags(false);

		try {
			//BookDAOをインスタンス化し、関連メソッドを呼び出す。
			GoodsDAO goodsDao = new GoodsDAO();

			if (authority == 2) {

				ArrayList<Goods> listbyuser = new ArrayList<Goods>();

				listbyuser = goodsDao.selectAll();

				//取得したListをリクエストスコープに"list"という名前で格納
				request.setAttribute("listbyuser", listbyuser);

			} else if (authority == 1) {

				ArrayList<Goods> listbyadmin = new ArrayList<Goods>();

				listbyadmin = goodsDao.selectAllOfAdmin();

				//取得したListをリクエストスコープに"list"という名前で格納
				request.setAttribute("listbyadmin", listbyadmin);

			}
		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "";
		} catch (Exception e) {
			error = "予期せぬエラーが発生しました。";
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		} finally {
			if (error == "") {
				request.getRequestDispatcher("/view/topmenu.jsp").forward(request, response);
			} else {
				//エラーがある場合はerrr.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
