package servlet;

import jakarta.servlet.http.HttpServlet;

public class BenefitListServlet extends HttpServlet {

}
