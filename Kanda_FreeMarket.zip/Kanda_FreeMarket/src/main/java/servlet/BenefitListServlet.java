/*
売上確認
作成者：出口莉菜
作成日：2024/6/20
*/
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Goods;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/benefit_list")

public class BenefitListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			GoodsDAO goodsDao = new GoodsDAO();

			ArrayList<Goods> benefitList = new ArrayList<Goods>();
			benefitList = goodsDao.benefitSelectAll();

			//リクエストスコープに登録	
			request.setAttribute("benefitList", benefitList);

		} catch (IllegalStateException e) {
			/*	request.setAttribute("error",
						ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR適当なエラーの名前を渡してください));*/
			return;

		} finally {
			if (request.getAttribute("error") != null) {

				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			} else {

				request.getRequestDispatcher("/view/benefitlist.jsp").forward(request, response);

			}
		}

	}

}