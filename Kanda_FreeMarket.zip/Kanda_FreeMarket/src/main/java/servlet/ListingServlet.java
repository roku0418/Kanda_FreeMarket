//////////////////////////////
//出品を処理するクラスです
//
//制作者：
//
//////////////////////////////
package servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bean.Goods;
import bean.Taginfo;
import common.AbsolutePaths;
import common.ErrorMessage;
import common.ErrorNum;
import common.Tags;
import dao.GoodsDAO;
import dao.TagDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

@WebServlet("/InsertServlet")
@MultipartConfig()
public class ListingServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//変数宣言
		String[] inputtags = request.getParameterValues("tags");
		Tags tags = new Tags(false);
		String filename = null;
		try {
			//入力データの文字コード指定
			request.setCharacterEncoding("UTF-8");

			//TODO ユーザーログインセッションチェックしてください
			HttpSession session = request.getSession();
			//			session.setAttribute("goodsname", goodsname);
			//			session.setAttribute("goodsprice",goodsprice);
			//			session.setAttribute("userid", userid);
			//			session.setAttribute("seller", seller);
			//			session.setAttribute("comment",comment);

			//DAOクラスオブジェクト生成
			GoodsDAO goodsDao = new GoodsDAO();

			//格納オブジェクト
			Goods goods = new Goods();

			//入力パラメーターを取得する
			goods.setGoodsname(request.getParameter("goodsname"));
			goods.setGoodsprice(Integer.parseInt(request.getParameter("goodsprice")));
			int userid = 1;
			//int userid = ((LoginData)session.getAttribute("user")).getUserid();
			goods.setSeller(userid);
			goods.setComment(request.getParameter("comment"));
			//TODO 以下DB設計を参考に値を入れること
			inputtags = new String[1];
			inputtags[0] = "appliances";

			//ファイル受け取り
			Part filePart = request.getPart("image");

			//ファイル名抽出
			//ヘッダー情報取得
			String contentDisposition = filePart.getHeader("content-disposition");
			//ファイルネーム取得用パターン生成
			Pattern pattern = Pattern.compile("filename=\".*\"");
			//パターンと一致する箇所を探索
			Matcher matcher = pattern.matcher(contentDisposition);
			//マッチチェック
			if (matcher.find()) {
				//ファイル名取得
				filename = matcher.group();
				String[] buff = filename.split("\"");
				filename = buff[1];

				//パラメーター取得
				try (InputStream inputStream = filePart.getInputStream()) {
					Files.copy(inputStream, new File(AbsolutePaths.getWebapp() + "/image/" + filename).toPath(),
							StandardCopyOption.REPLACE_EXISTING);
					inputStream.close();
				}

			}

			//taginfo用値設定
			Taginfo taginfo = new Taginfo();
			//タグ設定がなければnullを渡す
			if (inputtags.length == 0) {
				tags = null;
			} else {
				tags = tags.getSelectTags(inputtags);
			}

			taginfo.setTags(tags);
			taginfo.setGoodsname(request.getParameter("goodsname"));

			goods.setImage(filename);

			//DBに登録
			taginfo.setGoodsid(goodsDao.insert(goods, userid));

			//taginfoに登録
			TagDAO tagDao = new TagDAO();
			tagDao.insert(taginfo, inputtags);
			
			request.setAttribute("goods", goods);
			request.setAttribute("taginfo", taginfo);

			//価格が数値以外の時のエラー
		} catch (NumberFormatException e) {
			request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));

		} catch (IllegalStateException e) {
			request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));

		} catch (Exception e) {
			request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));

		} finally {
			//エラーの有無でフォワード先を呼び分ける
			if (request.getAttribute("error") != null) {
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			} else {
				//エラーがある場合はerror.jspにフォワード
				//登録された情報をもってlistingconfirm.jspにフォワード
//				response.sendRedirect(request.getContextPath() + "/view/listingconfirm.jsp");
//				return;
				request.getRequestDispatcher("/view/listingconfirm.jsp").forward(request, response);


				//	request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}
}