package servlet;

import java.io.IOException;

import bean.Goods;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ListingServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {
			//入力データの文字コード指定
			request.setCharacterEncoding("UTF-8");

			//入力パラメーターを取得する
			String itemName = request.getParameter("goodsid");
			String quantity = request.getParameter("quantity");
			String price = request.getParameter("price");
			String remarks = request.getParameter("remarks");

			//DAOクラスオブジェクト生成
			GoodsDAO goodsDao = new GoodsDAO();

			//登録する書籍情報を格納するBookオブジェクト
			Goods goods = new Goods();

			//画面からの入力情報を受け取りbookオブジェクトに格納
//			goods.setGoodsID(request.getParameter("itemName"));
//			goods.setQuantity(Integer.parseInt(request.getParameter("quantity")));
//			goods.setPrice(Integer.parseInt(request.getParameter("price")));
//			goods.setRemarks(request.getParameter("remarks"));

			//DBに登録
			//goodsDao.insert(goods);

			//価格が数値以外の時のエラー
		} catch (NumberFormatException e) {
			error = "価格の値が不正の為、書籍登録処理は行えませんでした。";
			cmd = "list";

		} catch (IllegalStateException e) {
			//error.jspにフォワード
			error = "DB接続エラーの為、書籍登録処理は行えませんでした。";
			cmd = "menu";

		} finally {
			//エラーの有無でフォワード先を呼び分ける
			if (error == "") {
				request.getRequestDispatcher("/list").forward(request, response);
			} else {
				//エラーがある場合はerror.jspにフォワード

				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}
}
