//秋岡　6/20
package servlet;

import java.io.IOException;

import bean.Goods;
import bean.Taginfo;
import common.ErrorMessage;
import common.ErrorNum;
import common.LoginData;
import common.Tags;
import dao.GoodsDAO;
import dao.TagDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/InsertServlet")
public class ListingServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//変数宣言
		String[] inputtags = request.getParameterValues("tags");
		Tags tags = new Tags();
		
		try {
			//入力データの文字コード指定
			request.setCharacterEncoding("UTF-8");

			//TODO ユーザーログインセッションチェックしてください
			HttpSession session = request.getSession();
			
			//DAOクラスオブジェクト生成
			GoodsDAO goodsDao = new GoodsDAO();
			
			//格納オブジェクト
			Goods goods = new Goods();
			
			//入力パラメーターを取得する
			goods.setGoodsname(request.getParameter("goodsname"));
			goods.setGoodsprice(Integer.parseInt(request.getParameter("goodsprice")));
			int userid = ((LoginData)session.getAttribute("user")).getUserid();
			goods.setSeller(userid);
			goods.setComment(request.getParameter("comment"));
			//TODO 以下DB設計を参考に値を入れること
			
			//taginfo用値設定
			Taginfo taginfo = new Taginfo();
			//タグ設定がなければnullを渡す
			if(inputtags.length == 0) {
				tags = null;
			}
			else {
				tags = tags.getSelectTags(inputtags);
			}
			
			taginfo.setTags(tags);
			taginfo.setGoodsname(request.getParameter("goodsname"));
			
			
			//画面からの入力情報を受け取りbookオブジェクトに格納
			
			//DBに登録
			goodsDao.insert(goods);
			//taginfoに登録
			TagDAO tagDao = new TagDAO();
			tagDao.insert(taginfo);

			//価格が数値以外の時のエラー
		} catch (NumberFormatException e) {
			request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));

		} catch (IllegalStateException e) {
			request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));

		} finally {
			//エラーの有無でフォワード先を呼び分ける
			if (request.getAttribute("error") != null) {
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			} else {
				//エラーがある場合はerror.jspにフォワード

				request.getRequestDispatcher("/view/listingcofirm.jsp").forward(request, response);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}
}
