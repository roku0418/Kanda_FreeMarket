/*
商品の詳細表示機能
作成者：出口莉菜
*/
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Goods;
import bean.Taginfo;
import dao.GoodsDAO;
import dao.TagDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/goodsdetail")
public class GoodsDetailServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
	            throws ServletException ,IOException{
		
	        String error = "";
	        String cmd ="";
	        
	        //格納変数
	        ArrayList<String> list = new ArrayList<>();
	        
	        try{

	        	int goodsid = Integer.parseInt(request.getParameter("goodsid"));
	        	//cmd = request.getParameter("cmd");
	        	
	        	GoodsDAO goodsDao = new GoodsDAO();
	        	//データベースから取得
	        	Goods goods = goodsDao.selectByGoodsID(goodsid);
	        	
	        	TagDAO tagDao = new TagDAO();
	        	Taginfo taginfo = tagDao.selectByGoodsid(goodsid);
	        	list = taginfo.getTags().getTagNameByJP(taginfo.getTags());
	        	
				request.setAttribute("goods", goods);
				request.setAttribute("taglist", list);
				
				

	        }catch (IllegalStateException e) {
	
	            error ="DB接続エラーの為、一覧表示はできませんでした。";
	            cmd = "view/menu.jsp";
	            //request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.DB_ERROR));
				return;
	
	        }finally{
	       
	        	request.getRequestDispatcher("/view/goodsdetail.jsp").forward(request, response);
	        		
	
	        }
	
	    }


}