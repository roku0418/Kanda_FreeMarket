/*
商品の詳細表示機能
作成者：出口莉菜
*/
package servlet;

import java.io.IOException;

import bean.Goods;
import common.ErrorMessage;
import common.ErrorNum;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Goodsdetail")
public class GoodsDetailServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";

		//入力データの文字コードの指定
		request.setCharacterEncoding("UTF-8");

		//パラメータの取得
		String itemId = request.getParameter("goodsid");
		String itemImage = request.getParameter("goodsimage");
		String itemName = request.getParameter("goodsname");
		String comment = request.getParameter("comment");
		String seller = request.getParameter("seller");
		String cmd = request.getParameter("cmd");

		try {

			//DAOクラスのオブジェクト生成
			GoodsDAO itemDao = new GoodsDAO();

			Goods item = itemDao.selectByGoodsID(itemId);

			//リクエストスコープに登録
			request.setAttribute("item", item);
			
			//TODO エラーチェック
			if(itemId == null || itemId.equals("")) {
            	request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR/*適当なエラーの名前を渡してください*/));
				return;
            }else if(itemImage == null || itemImage.equals("")) {
            	request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR/*適当なエラーの名前を渡してください*/));
				return;
            }else if(itemName == null || itemName.equals("")) {
            	request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR/*適当なエラーの名前を渡してください*/));
				return;
            }else if(comment == null || comment.equals("")) {
            	request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR/*適当なエラーの名前を渡してください*/));
				return;
            }else if(seller == null || seller.equals("")) {
            	request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR/*適当なエラーの名前を渡してください*/));
				return;
            }
		
		}catch (IllegalStateException e) {
        	request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR/*適当なエラーの名前を渡してください*/));
			return;

		} finally {
			//エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				if (cmd.equals("detail")) {
					request.getRequestDispatcher("/view/goodsdetail.jsp").forward(request, response);
				}
			} else {
				//エラーがある場合はerror.jspにフォワードする	
				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
