/*
商品の詳細表示機能
作成者：出口莉菜
*/
package servlet;

import java.io.IOException;

import bean.Goods;
import common.ErrorMessage;
import common.ErrorNum;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/goodsdetail")
public class GoodsDetailServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
	            throws ServletException ,IOException{
		
	        String error = "";
	        String cmd ="";
	        
	        try{

	        	//String goodsid = request.getParameter("goodsid");
	        	//cmd = request.getParameter("cmd");
	        	int goodsid = 1;
	        	
	        	GoodsDAO goodsDaoObj = new GoodsDAO();
	        	
	        	Goods goods = goodsDaoObj.selectByGoodsID(goodsid);
	        	
	        	goods.setGoodsid(1);
	        	goods.setImage("murasaki.png");
				goods.setGoodsname("goodsname");
				goods.setGoodsprice(1);
				goods.setSeller(1);
				goods.setComment("comment");
	        	
				request.setAttribute("goods", goods);
				


	        }catch (IllegalStateException e) {
	
	            error ="DB接続エラーの為、一覧表示はできませんでした。";
	            cmd = "view/menu.jsp";
	            //request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.DB_ERROR));
				return;
	
	        }finally{
	       
	        	request.getRequestDispatcher("/view/goodsdetail.jsp").forward(request, response);
	        		
	
	        }
	
	    }


}