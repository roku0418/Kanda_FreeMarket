package servlet;

import jakarta.servlet.http.HttpServlet;

public class LogoutServlet extends HttpServlet {

}
