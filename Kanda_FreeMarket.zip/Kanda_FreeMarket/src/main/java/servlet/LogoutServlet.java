package servlet;

import java.io.IOException;

import common.ErrorMessage;
import common.ErrorNum;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class LogoutServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			HttpSession session = request.getSession();
			session.invalidate();

		} catch (IllegalStateException e) {
			request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));
		} catch (Exception e) {
			request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));
		} finally {
			request.getRequestDispatcher("/view/login.jsp").forward(request, response);
		}
	}
}
