/*
商品の詳細表示機能
作成者：出口莉菜
*/
package servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Inputuserdata")
public class InputUserDataServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//パラメータの取得
		String item = request.getParameter("goodsid");

		try {
			
			//リクエストスコープに登録
			request.setAttribute("item", item);

		} finally {
			request.getRequestDispatcher("/view/inputuserdata.jsp").forward(request, response);
			
		}
	}

}
