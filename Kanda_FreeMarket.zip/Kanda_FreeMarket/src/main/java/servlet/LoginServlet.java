/*
ログイン機能・クッキー登録
作成者：出口莉菜
*/
package servlet;

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		UserDAO userDao = new UserDAO();

		try {
			//ユーザーとパスワードの入力値を取得
			String userid = request.getParameter("userid");
			String password = request.getParameter("password");

			//DBに同じユーザーIDとパスワードが登録されているか確認
			User user = userDao.selectByUser(userid, password);

			if (user.getUserid() < 0 || user.getPassword() == null) {
				//request.setAttribute("error", );
				return;
			} 
			else {
				//セッションスコープ登録
				HttpSession session = request.getSession();
				session.setAttribute("user", user);

				//ユーザーID用クッキー登録
				Cookie useridCookie = new Cookie("userid", userid);
				useridCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(useridCookie);

				//パスワード用クッキー登録
				Cookie passwordCookie = new Cookie("password", password);
				passwordCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(passwordCookie);

			}

			//DB接続エラー
		}
		catch (IllegalStateException e) {
			

		} 
		finally {
			
		}

		

	}
}
