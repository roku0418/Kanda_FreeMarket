/*
ログイン機能・クッキー登録
作成者：加藤吉人
*/
package servlet;

import java.io.IOException;

import bean.User;
import common.ErrorMessage;
import common.ErrorNum;
import common.LoginData;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//DAOオブジェクト宣言
		UserDAO userDao = new UserDAO();

		try {
			request.setCharacterEncoding("UTF-8");
			
			//ユーザーとパスワードの入力値を取得
			int userid = Integer.parseInt(request.getParameter("userid"));
			String password = request.getParameter("password");

			//DBに同じユーザーIDとパスワードが登録されているか確認
			User user = userDao.selectByUserId(userid);

			////TODO 戻り値エラーチェック
			//パスワード一致チェック
			if (userDao.loginCheck(userid) != password) {
				request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));
				return;
			} else {
				//セッションスコープ登録
				LoginData data = new LoginData();
				HttpSession session = request.getSession();
				session.setAttribute("user", data);

				//ユーザーID用クッキー登録
				Cookie useridCookie = new Cookie("userid", Integer.toString(user.getUserid()));
				useridCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(useridCookie);

				//パスワード用クッキー登録
				Cookie passwordCookie = new Cookie("password", user.getPassword());
				passwordCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(passwordCookie);

			}

			//TODO エラーチェック
		} catch (IllegalStateException e) {
			request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));

		} finally {
			if (request.getAttribute("error") != null) {
				//エラーページ遷移
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
			//リストサーブレットにフォワード
			request.getRequestDispatcher("/view/topmenu.jsp").forward(request, response);
		}

	}
}
