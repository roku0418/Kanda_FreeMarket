package servlet;

import java.io.IOException;

import common.ErrorMessage;
import common.ErrorNum;
import common.LoginData;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Buyconfirm")
public class BuyConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
	            throws ServletException ,IOException{
	       
	        try{
	        	//TODO やること。jspからグッズのIDがもらえるはずなのでそれを使ってgoodsの販売状況を変更する
	        	request.setCharacterEncoding("UTF-8");
	        	//TODO セッションログインチェックしてください
	        	HttpSession session = request.getSession();
	            LoginData user = (LoginData)session.getAttribute("user");
	            
	            //↓エラーの書き方
	            if(true/*条件判定してください*/) {
	            	request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR/*適当なエラーの名前を渡してください*/));
					return;
	            }
	        	
	            //グッズid取得
	            int goodsid = Integer.parseInt(request.getParameter("goodsid"));
	            
	            //データベースの取引状況を入金待ちに変更
	            GoodsDAO goodsDao = new GoodsDAO();
	            //TODO 暫定的に即値を入力。列挙型で管理したほうが良い？
	            goodsDao.setTradeStatus(goodsid, 2);
	            //goodsの取引者に自身のIDをセット
	            goodsDao.setTrader(user.getUserid());
	      
	        }catch (IllegalStateException e) {
	        	request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR/*適当なエラーの名前を渡してください*/));
				return;
	            
	        }finally{
	        	if(request.getAttribute("error") != null) {
		
		            request.getRequestDispatcher("/view/error.jsp").forward(request, response);
	        	
	        	}else {
	  
	        		request.getRequestDispatcher("/view/buyComfirm.jsp").forward(request, response);

	        	}
	        }

	}
}
