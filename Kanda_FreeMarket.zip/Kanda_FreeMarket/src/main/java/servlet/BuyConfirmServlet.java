//////////////////////////////
//購入完了を処理するクラスです
//
//制作者：
//
//////////////////////////////
package servlet;

import java.io.IOException;

import bean.Goods;
import common.LoginData;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.SendMail;
import util.SendMail2;


@WebServlet("/buyconfirm")
public class BuyConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";
		
		//コマンド取得
		cmd = (String)request.getAttribute("cmd");

		GoodsDAO goodsDaoObj = new GoodsDAO();
		
		try {
			int goodsid = Integer.parseInt(request.getParameter("goodsid"));
			Goods goods = goodsDaoObj.selectByGoodsID(goodsid);
			request.setCharacterEncoding("UTF-8");
			if("".equals(cmd) || cmd == null) {


				HttpSession session = request.getSession();
				LoginData user = (LoginData) session.getAttribute("user");
				//取引状況を取引中に変更
				goodsDaoObj.setTradeStatus(goodsid, 3);
				//取引者を登録
				
				goodsDaoObj.setTrader(goods.getSeller(), user.getUserid());
				

				request.setAttribute("goods", goods);

				
			}
			else if("payment".equals(cmd)){
				//入金されたら取引完了にする
				goodsDaoObj.setTradeStatus(goodsid, 4);
				SendMail.sendMail(goods);
			}
			else {
				goodsDaoObj.setTradeStatus(goodsid, 0);
				SendMail2.sendMail2(goods);
			}
			

		} catch (IllegalStateException e) {

			error = "DB接続エラーの為、一覧表示はできませんでした。";
			cmd = "view/error.jsp";

		} finally {
			if (!error.equals("")) {

				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);

				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			} else {

				request.getRequestDispatcher("/view/buyconfirm.jsp").forward(request, response);

			}
		}

	}
}
