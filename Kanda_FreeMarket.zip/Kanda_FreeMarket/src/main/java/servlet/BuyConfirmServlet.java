package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Goods;
import bean.Register;
import bean.User;
import dao.GoodsDAO;
import dao.RegisterDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Buyconfirm")
public class BuyConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
	            throws ServletException ,IOException{
		
	        String error = "";
	        String cmd = "";
	        
	        GoodsDAO goodsDaoObj = new GoodsDAO();
	        RegisterDAO registerDaoObj = new RegisterDAO();
	        ArrayList<Goods>list = new ArrayList<Goods>();
	        Register register = new Register();
	        try{
	        	//TODO やること。jspからグッズのIDがもらえるはずなのでそれを使ってgoodsの販売状況を変更する
	        	request.setCharacterEncoding("UTF-8");
	        	//TODO セッションログインチェックしてください
	        	HttpSession session = request.getSession();
	            User user = (User)session.getAttribute("user");
	        	
	            //グッズid取得
	            int goodsid = Integer.parseInt(request.getParameter("goodsid"));
	            
	            //データベースの取引状況を入金待ちに変更
	            GoodsDAO goodsDao = new GoodsDAO();
	            //TODO 暫定的に即値を入力。列挙型で管理したほうが良い？
	            goodsDao.setTradeStatus(goodsid, 2);
	            
	            ArrayList<Register> register_list = (ArrayList<Register>)session.getAttribute("register_list");

	            if(register_list != null) {
	            	for(int i=0; register_list.size() > i; i++) {
	            		register = (Register) register_list.get(i);
	            		Goods goods = goodsDaoObj.selectByGoodsID(register.getGoodsId());
	            		list.add(Goods);
	            		registerDaoObj.insert(register);
	            	}
	            }
	            
	            
	            request.setAttribute("book_list",list);
	            	
	            session.setAttribute("order_list",null);
	      
	        }catch (IllegalStateException e) {
	
	            error ="DB接続エラーの為、一覧表示はできませんでした。";
	            cmd = "view/error.jsp";

	        }finally{
	        	if(!error.equals("")) {
	
	        		request.setAttribute("error", error);
			        request.setAttribute("cmd", cmd);
		
		            request.getRequestDispatcher("/view/error.jsp").forward(request, response);
	        	
	        	}else {
	  
	        		request.getRequestDispatcher("/view/buyComfirm.jsp").forward(request, response);

	        	}
	        }

	}
}
