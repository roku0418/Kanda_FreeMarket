/**
 * 
 */
package servlet;

import java.io.IOException;

import bean.Goods;
import bean.User;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.SendMail;

/**

 * 
 */
@WebServlet("/buyconfirm")
public class BuyConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";

		GoodsDAO goodsDaoObj = new GoodsDAO();
		try {

			request.setCharacterEncoding("UTF-8");

			int goodsid = Integer.parseInt(request.getParameter("goodsid"));

			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			goodsDaoObj.setTradeStatus(goodsid, 0);
			Goods goods = goodsDaoObj.selectByGoodsID(goodsid);

			request.setAttribute("goods", goods);

			SendMail.sendMail(goods);

		} catch (IllegalStateException e) {

			error = "DB接続エラーの為、一覧表示はできませんでした。";
			cmd = "view/error.jsp";

		} finally {
			if (!error.equals("")) {

				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);

				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			} else {

				request.getRequestDispatcher("/view/buyconfirm.jsp").forward(request, response);

			}
		}

	}
}
