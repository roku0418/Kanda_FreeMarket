/*
 * 担当：原
 * 検索処理をするサーブレット
 */
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Goods;
import common.ErrorMessage;
import common.ErrorNum;
import common.LoginData;
import common.Tags;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/search")
public class SearchServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";
		String goodsname = request.getParameter("goodsname");
		String[] inputtags = request.getParameterValues("tags");
		Tags tags = new Tags(false);

		try {

			//BookDAOをインスタンス化し、関連メソッドを呼び出す。
			GoodsDAO goodsDao = new GoodsDAO();

			//TODO ハッシュキーコンテナを使う。

			//絞り込みがなければnullを渡す
			if (inputtags == null) {
				tags = null;
			} else {
				//入力されたタグのエラーチェック
				for(int i = 0; i < inputtags.length; i++) {
					if(tags.checkKey(inputtags[i]) == false) {
						request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.MISMATCH_NEWPASSWORD));
						return;
					}
				}
				//正常処理
				tags = tags.getSelectTags(inputtags);
			}
			ArrayList<Goods> searchlist = goodsDao.search(goodsname, tags);
			HttpSession session = request.getSession();
			//管理者かどうかでリストを選別
			//一般ユーザーなら購入可能のみ
			ArrayList<Goods> list = new ArrayList<>();
			if(((LoginData)session.getAttribute("user")).getAuthority() == 2) {
				for(int i = 0; i < searchlist.size(); i++) {
					if(searchlist.get(i).getTrade_status() == 1)
						list.add(searchlist.get(i));
					
				}
			}
			else {
				list = searchlist;
			}

			//取得したListをリクエストスコープに"list"という名前で格納
			request.setAttribute("searchlist", list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "";
		} catch (Exception e) {
			error = "予期せぬエラーが発生しました。";
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		} finally {
			if (error == "") {
				request.getRequestDispatcher("/view/topmenu.jsp").forward(request, response);
			} else {
				//エラーがある場合はerrr.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}

}
