/*
 * 担当：原
 * 検索処理をするサーブレット
 */
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Goods;
import common.LoginData;
import common.Tags;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/search")
public class SearchServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";
		String goodsname = request.getParameter("goodsname");
		String[] inputtags = request.getParameterValues("tags");
		HttpSession session = request.getSession();
		LoginData data = (LoginData) session.getAttribute("user");
		int authority = data.getAuthority();
		Tags tags = new Tags(false);

		try {

			//BookDAOをインスタンス化し、関連メソッドを呼び出す。
			GoodsDAO goodsDao = new GoodsDAO();

			//Boolean型のArralist、taglistを生成
			ArrayList<Boolean> taglist = new ArrayList<Boolean>();

			//TODO ハッシュキーコンテナを使う。

			//絞り込みがなければnullを渡す
			if (inputtags == null) {
				tags = null;
			} else {
				tags = tags.getSelectTags(inputtags);
			}
			ArrayList<Goods> searchlist = goodsDao.search(goodsname, tags);

			//取得したListをリクエストスコープに"list"という名前で格納
			request.setAttribute("searchlist", searchlist);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "";
		} catch (Exception e) {
			error = "予期せぬエラーが発生しました。";
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		} finally {
			if (error == "") {
				request.getRequestDispatcher("/view/topmenu.jsp").forward(request, response);
			} else {
				//エラーがある場合はerrr.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}

}
