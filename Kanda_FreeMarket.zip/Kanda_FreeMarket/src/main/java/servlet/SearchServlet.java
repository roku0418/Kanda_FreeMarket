package servlet;

import jakarta.servlet.http.HttpServlet;

public class SearchServlet extends HttpServlet {
//	public void doGet(HttpServletRequest request, HttpServletResponse response)
//	throws ServletException, IOException {
//String error = "";
//String cmd = "";
//
//try {
//	ItemDAO itemDao = new ItemDAO();
//
//	//検索した書籍情報を格納するArrayListオブジェクト生成
//	ArrayList<Item> itemList = new ArrayList<Item>();
//	itemList = itemDao.selectAll();
//
//	//リクエストスコープに登録
//	request.setAttribute("item_list", itemList);
//
//} catch (IllegalStateException e) {
//	//error.jspにフォワード
//	error = "DB接続エラーの為、一覧表示は行えませんでした。";
//	cmd = "menu";
//
//} finally {
//	if (error == "") {
//		request.getRequestDispatcher("/view/list.jsp").forward(request, response);
//	} else {
//		//エラーがある場合はerrr.jspにフォワードする
//		request.setAttribute("error", error);
//		request.setAttribute("cmd", cmd);
//		request.getRequestDispatcher("/view/error.jsp").forward(request, response);
//	}
//}
//}

}
