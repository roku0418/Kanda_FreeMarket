package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Goods;
import common.Tags;
import dao.GoodsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class SearchServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";
		String goodsname = request.getParameter("goodsname");
		String[] inputtags = request.getParameterValues("tags");
		Tags tags = new Tags();

		try {
			GoodsDAO goodsDao = new GoodsDAO();

			//検索した書籍情報を格納するArrayListオブジェクト生成
			ArrayList<Goods> itemList = new ArrayList<Goods>();
			itemList = goodsDao.selectAll();

			//リクエストスコープに登録
			request.setAttribute("item_list", itemList);

		} catch (IllegalStateException e) {
			//error.jspにフォワード
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "";
		} finally {
			if (error == "") {
				request.getRequestDispatcher("/view/").forward(request, response);
			} else {
				//エラーがある場合はerrr.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

		try {

			//BookDAOをインスタンス化し、関連メソッドを呼び出す。
			GoodsDAO goodsDao = new GoodsDAO();

			//Boolean型のArralist、taglistを生成
			ArrayList<Boolean> taglist = new ArrayList<Boolean>();
			
			//TODO ハッシュキーコンテナを使う。
			
//			//TagsクラスのgetListメソッドを実行して生成したリストに代入
//			taglist = tags.getList();
//			//リストのサイズ分、
//			for (int i = 0; i < taglist.size(); i++) {
//				if (taglist.get(i) == true) {
//					break;
//				}
//
//				if (i >= taglist.size()) {
//					tags = null;
//					break;
//				}
//			}

			//絞り込みがなければnullを渡す
			if(inputtags.length == 0) {
				tags = null;
			}
			else {
				tags = tags.getSelectTags(inputtags);
			}
			ArrayList<Goods> listbyadmin = goodsDao.search(goodsname, tags);

			//取得したListをリクエストスコープに"list"という名前で格納
			request.setAttribute("listbyadmin", listbyadmin);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "";
		} catch (Exception e) {
			error = "予期せぬエラーが発生しました。";
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		} finally {
			if (error == "") {
				request.getRequestDispatcher("/view/list.jsp").forward(request, response);
			} else {
				//エラーがある場合はerrr.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
