/*
ユーザー一覧画面
作成者：出口莉菜
作成日：2024/6/20
*/

package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/userList")
public class UserListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			//DAOオブジェクト宣言
			UserDAO userDao = new UserDAO();

			//ユーザー一覧
			//配列宣言
			ArrayList<User> userList = new ArrayList<User>();
			userList = userDao.getUserList();

			//検索結果を持ってuserlist.jspにフォワード
			request.setAttribute("userList", userList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。 ";
			cmd = "menu";

		} finally {
			// リソースの開放
			if (error.equals("")) {
				request.getRequestDispatcher("/view/userlist.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}

		}
	}
}