package servlet;

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class SignupServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			
			//ユーザー登録の情報を取得
			String userid = request.getParameter("userid");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			String authority = request.getParameter("authority");
			
			//オブジェクトに情報を設定する
			User objUser = new User();
//			 objUser.setUserid(userid);
//			 objUser.setPassword(password);
//			 objUser.setEmail(email);
//			 objUser.setAuthority(authority);
			 
			 
			 //ユーザー登録を行う
			 UserDAO objUserDao = new UserDAO();
			 //objUserDao.insert(objUser);
			 
			 
		} catch (Exception e) {
			//request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));

		} finally {
			if (request.getAttribute("error") != null) {
				//エラーページ遷移
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
			//リストサーブレットにフォワード
			request.getRequestDispatcher("").forward(request, response);
		}
	}
}
