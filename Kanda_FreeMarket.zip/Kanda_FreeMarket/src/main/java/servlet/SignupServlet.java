package servlet;

import java.io.IOException;

import bean.User;
import common.ErrorMessage;
import common.ErrorNum;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {

			//ユーザー登録の情報を取得
			int userid = Integer.parseInt(request.getParameter("userid"));
			String password = request.getParameter("password");
			String handle_name = request.getParameter("handle_name");
			String email = request.getParameter("email");
			int phone = Integer.parseInt(request.getParameter("phone"));
			String real_ame = request.getParameter("real_ame");
			int authority = Integer.parseInt(request.getParameter("authority"));

			//オブジェクトに情報を設定する
			User objUser = new User();
			objUser.setUserid(userid);
			objUser.setPassword(password);
			objUser.setHandle_name(handle_name);
			objUser.setEmail(email);
			objUser.setPhone(phone);
			objUser.setReal_name(real_ame);
			objUser.setAuthority(authority);

			//ユーザー登録を行う
			UserDAO objUserDao = new UserDAO();
			objUserDao.insert(objUser);

		} catch (Exception e) {
			request.setAttribute("error", ErrorMessage.getErrorMessage(ErrorNum.SESSION_EXPIRED_ERROR));

		} finally {
			if (request.getAttribute("error") != null) {
				//エラーページ遷移
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
			//リストサーブレットにフォワード
			request.getRequestDispatcher("/view/signup.jsp").forward(request, response);
		}
	}
}
