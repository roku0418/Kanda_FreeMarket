package servlet;

import java.io.IOException;

import bean.Goods;
import bean.User;
import dao.GoodsDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/userhome")
public class UserHomeServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{
	
		String error = "";
		String cmd = "";
		
		try {
			//文字コードを設定する
			request.setCharacterEncoding("UTF-8");

			//isbn,title,price等の入力パラメータを取得する
			int userid = Integer.parseInt(request.getParameter("userid"));
			cmd = request.getParameter("cmd");
			
			//ユーザーDAOをインスタンス化する
			UserDAO userDao = new UserDAO();
			
			User user = new User();
			
			user = userDao.selectByUserId(userid);
			
			//ユーザーDAOをインスタンス化する
			GoodsDAO goodsDao = new GoodsDAO();
			
			Goods goods = new Goods();
			
			
			//goodsDAOから
			//goods = ;
			
		
			
			// 削除対象の有無のエラーチェック
		
			// 詳細情報のエラーチェック
			if (String.valueOf(user.getUserid()) == null) {
				if (cmd.equals("detail")) {
					error = "表示対象のUseridが存在しない為、	アカウント情報は表示できませんでした。";
				}
					cmd = "list";
				return;
			}
			
			request.setAttribute("user", user);
			request.setAttribute("cmd", cmd);
			
		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "menu";

		} finally {
			// エラーの有無でフォワード先を呼び分ける
				if (error.equals("")) {
					// cmdの値でフォワード先を呼び分ける
					
						request.getRequestDispatcher("/view/userhome.jsp").forward(request, response);
					
				} else {
					// エラーが有る場合はerror.jspにフォワードする
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
	
				}
		}
	
	}
}