package servlet;

import jakarta.servlet.http.HttpServlet;

public class UserHomeServlet extends HttpServlet {

}
