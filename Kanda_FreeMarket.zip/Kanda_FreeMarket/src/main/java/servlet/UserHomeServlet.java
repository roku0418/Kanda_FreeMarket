package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Goods;
import bean.Register;
import bean.User;
import dao.GoodsDAO;
import dao.RegisterDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;




@WebServlet("/userhome")
public class UserHomeServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{
	
		String error = "";
		String cmd = "";
		
		try {
			//文字コードを設定する
			request.setCharacterEncoding("UTF-8");

			//isbn,title,price等の入力パラメータを取得する
			int userid = Integer.parseInt(request.getParameter("userid"));
			cmd = request.getParameter("cmd");
			
			//ユーザーの情報処理
			UserDAO userDao = new UserDAO();
			
			User user = new User();
			
			user = userDao.selectByUserId(userid);
			
			//住所の情報処理
			 ArrayList<Register> registerList = new ArrayList<Register>();
			 
			 RegisterDAO registerDao = new RegisterDAO();
			 
			 registerList = registerDao.selectByUserId(userid);
			
			//商品の情報処理
			 ArrayList<Goods> goodsList = new ArrayList<Goods>();
			 
			 GoodsDAO goodsDao = new GoodsDAO();
			 
			 goodsList = goodsDao.selectAll();
		
			
			// 削除対象の有無のエラーチェック
		
			// 詳細情報のエラーチェック
			if (String.valueOf(user.getUserid()) == null) {
				if (cmd.equals("detail")) {
					error = "表示対象のUseridが存在しない為、	アカウント情報は表示できませんでした。";
				}
					cmd = "list";
				return;
			}
			
			//jspにもっていく準備
			request.setAttribute("user", user);
			request.setAttribute("cmd", cmd);
			request.setAttribute("goodsList", goodsList);
			request.setAttribute("registerList", registerList);
		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "menu";

		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
					
						request.getRequestDispatcher("/view/userhome.jsp").forward(request, response);
					
				} else {
					// エラーが有る場合はerror.jspにフォワードする
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
					}
			}
		}
	}