package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Goods;
import bean.User;
import bean.UserAddress;
import common.LoginData;
import dao.GoodsDAO;
import dao.UserAddressDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/userhome")
public class UserHomeServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{
	
		String error = "";
		String cmd = "";
		
		try {
			//文字コードを設定する
			request.setCharacterEncoding("UTF-8");

			
			
//			int userid = Integer.parseInt(request.getParameter("userid"));
			cmd = request.getParameter("cmd") == null ? "" : request.getParameter("cmd");
			
			HttpSession session = request.getSession();
			
			//ユーザーの情報取得
			LoginData data = (LoginData)session.getAttribute("user");
			UserDAO userDao = new UserDAO();
			
			User user = new User();
			user = userDao.selectByUserId(data.getUserid());
			
			//住所の情報取得
			 ArrayList<UserAddress> registerList = new ArrayList<UserAddress>();
			 UserAddressDAO registerDao = new UserAddressDAO();
			 registerList = registerDao.selectByUserId(data.getUserid());
			
			//商品の情報取得
			 ArrayList<Goods> goodsList = new ArrayList<Goods>();
			 GoodsDAO goodsDao = new GoodsDAO();
			 goodsList = goodsDao.selectAll();
			
			 //購入履歴の取得
			 ArrayList<Goods> goodsbuyhistoryList = new ArrayList<Goods>();
			 goodsbuyhistoryList = goodsDao.getBuyHistory(data.getUserid());
			 
			 //出品履歴
			 ArrayList<Goods> goodshistoryList = new ArrayList<Goods>();
			 goodshistoryList = goodsDao.getBuyHistory(data.getUserid());
			 
			
			// 削除対象の有無のエラーチェック
		
			// 詳細情報のエラーチェック
			if (String.valueOf(user.getUserid()) == null) {
				if (cmd.equals("detail")) {
					error = "表示対象のUseridが存在しない為、	アカウント情報は表示できませんでした。";
				}
					cmd = "list";
				return;
			}
			
			//jspにもっていく準備
			request.setAttribute("user", user);
			request.setAttribute("cmd", cmd);
			request.setAttribute("goodsList", goodsList);
			request.setAttribute("registerList", registerList);
			request.setAttribute("goodsbuyhistoryList", goodsbuyhistoryList);
			request.setAttribute("goodshistoryList", goodshistoryList);
		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "menu";

		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
					
						request.getRequestDispatcher("/view/userhome.jsp").forward(request, response);
					
				} else {
					// エラーが有る場合はerror.jspにフォワードする
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
					}
			}
		}
	}