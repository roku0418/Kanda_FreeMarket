//////////////////////////////
//Taginfoオブジェクトを定義するクラスです。
//
//制作者：加納七翔
//
//////////////////////////////
package bean;

import common.Tags;

public class Taginfo {
	//変数宣言
	private int goodsid;
	private String goodsname;
	private Tags tags;
	
	//アクセサメソッド
	public int getGoodsid() {
		return goodsid;
	}
	public void setGoodsid(int goodsid) {
		this.goodsid = goodsid;
	}
	public String getGoodsname() {
		return goodsname;
	}
	public void setGoodsname(String goodsname) {
		this.goodsname = goodsname;
	}
	public Tags getTags() {
		return tags;
	}
	public void setTags(Tags tags) {
		this.tags = tags;
	}	
	
}
