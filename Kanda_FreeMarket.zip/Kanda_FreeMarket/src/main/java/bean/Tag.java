package bean;

public class Tag {
	private int goodsid;
	private String goodsname;
	//必要なタグの数だけ変数を追加
	
	//アクセサメソッド
	public int getGoodsid() {
		return goodsid;
	}
	public void setGoodsid(int goodsid) {
		this.goodsid = goodsid;
	}
	public String getGoodsname() {
		return goodsname;
	}
	public void setGoodsname(String goodsname) {
		this.goodsname = goodsname;
	}
	
	
}
