package bean;

public class LoginData {
	private int userid;
	private String password;
	
	
	
	public LoginData() {
		this.userid = -1;
		this.password = null;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
