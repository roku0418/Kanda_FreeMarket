//////////////////////////////
//Userオブジェクトを定義するクラスです。
//
//制作者：加納七翔
//
//////////////////////////////
package bean;

public class User {
	//変数宣言
	private int userid;
	private String password;
	private String handle_name;
	private String email;
	private int phone;
	private String real_name;
	private int authority;

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHandle_name() {
		return handle_name;
	}

	public void setHandle_name(String handle_name) {
		this.handle_name = handle_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getReal_name() {
		return real_name;
	}

	public void setReal_name(String real_name) {
		this.real_name = real_name;
	}

	public int getAuthority() {
		return authority;
	}

	public void setAuthority(int authority) {
		this.authority = authority;
	}

	/*	//最終出品日
			public String getFinal_sale_date() {
				return final_sale_date;
			}
	
			public void setFinal_sale_date(String final_sale_date) {
				this.final_sale_date = final_sale_date;
			}
	
		//出品数
			public int getTotal_sale_quantity() {
				return total_sale_quantity;
			}
	
			public void setTotal_sale_quantity(int total_sale_quantity) {
				this.total_sale_quantity = total_sale_quantity;
			}
	*/

}
