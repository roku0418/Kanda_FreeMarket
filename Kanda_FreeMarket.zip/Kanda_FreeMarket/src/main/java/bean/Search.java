package bean;

public class Search {
	//ファイル名を格納する変数
	private String image;
	//商品番号を格納する変数
	private String goodsid;
	//商品名を格納する変数
	private String goodsname;
	//取引状況を格納する変数
	private int trade_status;

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getGoodsid() {
		return goodsid;
	}

	public void setGoodsid(String goodsid) {
		this.goodsid = goodsid;
	}

	public String getGoodsname() {
		return goodsname;
	}

	public void setGoodsname(String goodsname) {
		this.goodsname = goodsname;
	}

	public int getTrade_status() {
		return trade_status;
	}

	public void setTrade_status(int trade_status) {
		this.trade_status = trade_status;
	}

}
