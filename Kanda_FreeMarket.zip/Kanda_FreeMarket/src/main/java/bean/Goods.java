package bean;

public class Goods {

	//ファイル名を格納する変数
	private String image;
	//商品番号を格納する変数
	private int goodsid;
	//商品名を格納する変数
	private String goodsname;
	//出品者を格納する変数
	private int seller;
	//コメントを格納する変数
	private String comment;
	//取引者を格納する変数
	private String trader;
	//商品価格を格納する変数	
	private int goodsprice;
	//出品日を格納する変数
	private String sell_date;
	//更新日を格納する変数
	private String update_date;
	//商品状態を格納する変数
	private int goods_status;
	//取引状況を格納する変数
	private int trade_status;
	//取引成立日を格納する変数
	private String sold_date;

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public int getGoodsid() {
		return goodsid;
	}

	public void setGoodsid(int goodsid) {
		this.goodsid = goodsid;
	}

	public String getGoodsname() {
		return goodsname;
	}

	public void setGoodsname(String goodsname) {
		this.goodsname = goodsname;
	}

	public int getSeller() {
		return seller;
	}

	public void setSeller(int seller) {
		this.seller = seller;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getTrader() {
		return trader;
	}

	public void setTrader(String trader) {
		this.trader = trader;
	}

	public int getGoodsprice() {
		return goodsprice;
	}

	public void setGoodsprice(int goodsprice) {
		this.goodsprice = goodsprice;
	}

	public String getSell_date() {
		return sell_date;
	}

	public void setSell_date(String sell_date) {
		this.sell_date = sell_date;
	}

	public String getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(String update_date) {
		this.update_date = update_date;
	}

	public int getGoods_status() {
		return goods_status;
	}

	public void setGoods_status(int goods_status) {
		this.goods_status = goods_status;
	}

	public int getTrade_status() {
		return trade_status;
	}

	public void setTrade_status(int trade_status) {
		this.trade_status = trade_status;
	}

	public String getSold_date() {
		return sold_date;
	}

	public void setSold_date(String sold_date) {
		this.sold_date = sold_date;
	}

}