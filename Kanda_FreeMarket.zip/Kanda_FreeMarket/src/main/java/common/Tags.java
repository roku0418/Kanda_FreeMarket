//////////////////////////////
//タグを管理、操作クラスです。
//
//制作者：加納七翔
//
//////////////////////////////
package common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Tags {

	HashMap<String, Boolean> tagmap = new HashMap<>(); 
	HashMap<String, String> namemap = new HashMap<>();
	
	
	//コンストラクタ
	public Tags(boolean check) {
		//TODO タグが増えるたびに追加が必要
		tagmap.put("appliances", check);
		tagmap.put("clothes", check);
		tagmap.put("book", check);
		tagmap.put("comic", check);
		tagmap.put("library", check);
		tagmap.put("magazine", check);
		tagmap.put("Light_Novel", check);
		tagmap.put("toy", check);
		tagmap.put("game", check);
		tagmap.put("Switch", check);
		tagmap.put("PS4", check);
		tagmap.put("PS5", check);
		tagmap.put("kids", check);
		tagmap.put("men", check);
		tagmap.put("women", check);
		tagmap.put("accessories", check);
		tagmap.put("bag", check);
		tagmap.put("furniture", check);
		tagmap.put("interior", check);
		tagmap.put("tables", check);
		tagmap.put("chair", check);
		tagmap.put("shelf", check);
		tagmap.put("new", check);
		tagmap.put("used", check);
		tagmap.put("Unopened", check);
		tagmap.put("others", check);
		
		namemap.put("appliances","家電" );
		namemap.put("clothes","ファッション" );
		namemap.put("book","本" );
		namemap.put("comic","コミック" );
		namemap.put("library","文庫" );
		namemap.put("magazine","雑誌" );
		namemap.put("Light_Novel","ラノベ" );
		namemap.put("toy","おもちゃ" );
		namemap.put("game","ゲーム" );
		namemap.put("Switch","Switch" );
		namemap.put("PS4","PS4" );
		namemap.put("PS5","PS5" );
		namemap.put("kids","キッズ" );
		namemap.put("men","メンズ" );
		namemap.put("women","レディース" );
		namemap.put("accessories","アクセサリー" );
		namemap.put("bag","バッグ" );
		namemap.put("furniture","家具" );
		namemap.put("interior","インテリア" );
		namemap.put("tables","テーブル" );
		namemap.put("chair","椅子" );
		namemap.put("shelf","収納棚" );
		namemap.put("new","新品" );
		namemap.put("used","中古" );
		namemap.put("Unopened","未開封" );
		namemap.put("others","その他" );
	}
	
	public ArrayList<Boolean> getList(){
		ArrayList<Boolean> taglist = new ArrayList<Boolean>();
		
		return taglist;
	}
	
	public Tags getSelectTags(String[] select) {
		for(int i = 0; i< select.length; i++) {
			tagmap.put(select[i], true);
		}
		
		return this;
	}
	
	public int checkTag(String name) {
		if(tagmap.get(name) != null) {
			if(tagmap.get(name) == true) {
				return 1;
			}
			else {
				return 0;
			}
		}
		//TODO error検査して処理してください
		return -1;
	}
	
	public HashMap<String, Boolean> getMap(){
		return tagmap;
	}
	
	public void setTag(String name, boolean tag) {
		tagmap.put(name, tag);
	}
	
	public boolean checkKey(String keyname) {
		return tagmap.containsKey(keyname);
	}
	
	public ArrayList<String> getTagNameByJP(Tags tags){
		ArrayList<String> list = new ArrayList<>();
		for(Map.Entry<String, Boolean> entry : tags.getMap().entrySet()) {
			if(entry.getValue() == true) {
				list.add(namemap.get(entry.getKey()));
			}
		}
		
		return list;
	}
}
