package common;

import java.util.ArrayList;

public class Tags {

	//必要なタグの数だけ変数を追加
	//家電
	private boolean appliances;
	//服
	private boolean clothes;
	
	public boolean isAppliances() {
		return appliances;
	}
	public void setAppliances(boolean appliances) {
		this.appliances = appliances;
	}
	public boolean isClothes() {
		return clothes;
	}
	public void setClothes(boolean clothes) {
		this.clothes = clothes;
	}
	
	public ArrayList<Boolean> getList(){
		ArrayList<Boolean> taglist = new ArrayList<Boolean>();
		
		taglist.add(appliances);
		taglist.add(clothes);
		
		return taglist;
	}
	
	public Tags getSelectTags(String[] select) {
		
		
		return new Tags();
	}
}
