package common;

import java.util.ArrayList;
import java.util.HashMap;

public class Tags {

	HashMap<String, Boolean> tagmap = new HashMap<>(); 
	
	//必要なタグの数だけ変数を追加
	//家電
	private boolean appliances;
	//服
	private boolean clothes;
	
	public boolean isAppliances() {
		return appliances;
	}
	public void setAppliances(boolean appliances) {
		this.appliances = appliances;
	}
	public boolean isClothes() {
		return clothes;
	}
	public void setClothes(boolean clothes) {
		this.clothes = clothes;
	}
	
	//コンストラクタ
	public Tags(boolean check) {
		//TODO タグが増えるたびに追加が必要
		tagmap.put("appliances", appliances);
		tagmap.put("clothes", clothes);
		
		appliances = check;
		clothes = check;
	}
	
	public ArrayList<Boolean> getList(){
		ArrayList<Boolean> taglist = new ArrayList<Boolean>();
		
		taglist.add(appliances);
		taglist.add(clothes);
		
		return taglist;
	}
	
	public Tags getSelectTags(String[] select) {
		for(int i = 0; i< select.length; i++) {
			tagmap.put(select[i], true);
		}
		
		return this;
	}
	
	public int checkTag(String name) {
		if(tagmap.get(name) != null) {
			if(tagmap.get(name) == true) {
				return 1;
			}
			else {
				return 0;
			}
		}
		//TODO error検査して処理してください
		return -1;
	}
}
