//////////////////////////////
//絶対パスを取得するクラスです。
//
//制作者：加納七翔
//
//////////////////////////////
package common;

public class AbsolutePaths {
	private static String webapp = "C:\\usr\\kis_java_pkg_2023\\workspace\\Kanda_FreeMarket\\src\\main\\webapp";

	public static String getWebapp() {
		return webapp;
	}

	public static void setWebapp(String webapp) {
		AbsolutePaths.webapp = webapp;
	}
	
	
}
