/////////////////////////////////////////
//DB接続を行いConnectionを返すクラスです
//
//製作者：加納七翔
//制作日：2024/06/19
/////////////////////////////////////////
package common;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnecter {
	//自身のインスタンス
	private static DBConnecter instance;
	
	//DB接続用変数
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/kanda_freemarket";
	private static String USER = "root";
	private static String PASS = "root123";
	
	//オブジェクト生成禁止
	private DBConnecter() {
		
	}
	
	//オブジェクトゲッター
	public static DBConnecter get() {
		if(instance == null) {
			instance = new DBConnecter();
		}
		
		return instance;
	}
	
	//DB接続
	public static Connection getConnection() {

		try {
			//Class.forNameメソッドを利用してJDBCドライバーをロード
			Class.forName(RDB_DRIVE);
			//DriverManager.getConnectionメソッドを利用してConnectionオブジェクトを生成
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			//生成されたConnectionオブジェクトをリターン
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
}
