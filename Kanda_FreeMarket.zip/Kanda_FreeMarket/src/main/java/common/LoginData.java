//////////////////////////////
//ログインデータを保存する用のクラスです。
//
//制作者：加納七翔
//
//////////////////////////////
package common;

public class LoginData {
	private int userid;
	private String password;
	private int authority;
	
	
	
	public LoginData() {
		this.userid = -1;
		this.password = null;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAuthority() {
		return authority;
	}
	public void setAuthority(int authority) {
		this.authority = authority;
	}
	
	
	
	
}
