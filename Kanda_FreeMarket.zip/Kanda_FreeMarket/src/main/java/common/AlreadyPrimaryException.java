package common;

public class AlreadyPrimaryException extends Exception 
{
	// warning回避
	private static final long serialVersionUID = 1L;
	
	public AlreadyPrimaryException () 
	{
		
	}
	
	public AlreadyPrimaryException (String msg) 
	{
		super(msg);
	}
}
