package common;

public class ErrorData
{
	private String errormessage;
	private String pagename;
	private String path;
	
	public ErrorData(String message, String name, String path)
	{
		errormessage = message;
		pagename = name;
		this.path = path;
	}

	public String getErrormessage()
	{
		return errormessage;
	}

	public String getPagename() 
	{
		return pagename;
	}

	public String getPath()
	{
		return path;
	}
	
	
}
