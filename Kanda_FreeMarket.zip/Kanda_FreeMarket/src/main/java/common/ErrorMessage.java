//////////////////////////////
//エラー表示文を返すクラスです。
//
//制作者：加納七翔
//
//////////////////////////////
package common;

public class ErrorMessage 
{
	//エラー列挙型をもらってエラーメッセージを返す関数
	public static ErrorData getErrorMessage(ErrorNum error)
	{
		switch(error)
		{
		case NON_INPUT_ISBN_ERROR:
			return new ErrorData("ISBNが未入力の為、書籍登録処理は行えませんでした。", "一覧表示", "/list");
		
		case ALREADY_REGISTERED_ERROR:
			return new ErrorData("入力ISBNは既に登録済みの為、書籍登録処理は行えませんでした。", "一覧表示", "/list");
		
		case NON_INPUT_TITLE_ERROR:
			return new ErrorData("タイトルが未入力の為、書籍登録処理は行えませんでした。", "一覧表示", "/list");
		
		case NON_INPUT_PRICE_ERROR:
			return new ErrorData("価格が未入力の為、書籍登録処理は行えませんでした。", "一覧表示", "/list");
		
		case PRICE_ERROR:
			return new ErrorData("価格の値が不正の為、書籍登録処理は行えませんでした。", "一覧表示", "/list");
		
		case DB_ERROR:
			return new ErrorData("DB接続エラーの為、書籍登録処理は行えませんでした。", "メニュー画面", "/view/menu.jsp");
		
		case NON_REGISTERED_ERROE:
			return new ErrorData("表示対象の書籍が存在しない為、詳細情報は表示できませんでした。", "一覧表示", "/list");
		
		case NON_REGISTERD_CANT_DELETE_ERROR:
			return new ErrorData("削除対象の書籍が存在しない為、書籍削除処理は行えませんでした。", "一覧表示", "/list");
		
		case SESSION_EXPIRED_ERROR:
			return new ErrorData("セッション切れのため処理を完了できません", "ログアウト", "/logout");
		
		case NOTHING_IN_CART_CANT_BUY_ERROR:
			return new ErrorData("カートの中に何もなかったので購入はできません。", "メニュー画面", "/view/menu.jsp");
		
		case NON_INITFILE_ERROR:
			return new ErrorData("初期データファイルが無い為、登録は行えません。", "メニュー画面", "/view/menu.jsp");
		
		case INITFILE_MISTAKE_ERROR:
			return new ErrorData("初期データファイルが不備がある為、登録は行えません。", "メニュー画面", "/view/menu.jsp");
		
		case ALREADY_DATA_EXISTS_ERROR:
			return new ErrorData("DBにはデータが存在するので、初期データは登録できません。", "メニュー画面", "/view/menu.jsp");
		
		case NON_INPUT_OLDPASSWORD:
			return new ErrorData("旧パスワードを入力して下さい！", "メニュー画面", "/view/menu.jsp");
		
		case NON_INPUT_NEWPASSWORD:
			return new ErrorData("新パスワードを入力して下さい！", "メニュー画面", "/view/menu.jsp");
		
		case NON_INPUT_CHECKNEWPASSWORD:
			return new ErrorData("新パスワード(確認用)を入力して下さい！", "メニュー画面", "/view/menu.jsp");
		
		case MISMATCH_OLDPASSWORD:
			return new ErrorData("旧パスワードが間違っています！", "メニュー画面", "/view/menu.jsp");
		
		case MISMATCH_NEWPASSWORD:
			return new ErrorData("確認パスワードが合っていません！", "メニュー画面", "/view/menu.jsp");
		
		case CANT_CREATE_QUERY:
			return new ErrorData("クエリ発行に失敗しました。", "ログアウト", "/logout");
		
		case NON_INPUT_USER:
			return new ErrorData("ユーザー入力値不正の為、処理を完了できません。", "ユーザー一覧", "/listUser");
		
		case NON_INPUT_PASSWORD:
			return new ErrorData("パスワード入力値不正の為、処理を完了できません。", "ユーザー一覧", "/listUser");
		
		case NON_INPUT_CHECKPASSWORD:
			return new ErrorData("パスワード(確認用)入力値不正の為、処理を完了できません。", "ユーザー一覧", "/listUser");
		
		case NON_INPUT_EMAIL:
			return new ErrorData("Ｅメール入力値不正の為、処理を完了できません。", "ユーザー一覧", "/listUser");
		
		case ALREADY_USED_USER:
			return new ErrorData("入力ユーザー名は既に使用済みの為、処理を完了できません。", "ユーザー一覧", "/listUser");
		
		default:
			return new ErrorData("予期しないエラーが発生しました", "ログイン画面", "/view/login.jsp");
		}
	}
}

