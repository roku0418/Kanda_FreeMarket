package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.UserAddress;
import common.DBConnecter;

public class UserAddressDAO {
	public ArrayList<UserAddress> selectByUserId(int userid) {

		UserAddress user;
		Connection con = null;
		Statement smt = null;
		ArrayList<UserAddress> regilist = new ArrayList<UserAddress>();
		try {
			String sql = "SELECT * FROM registered_address WHERE user =" + userid;

			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				user = new UserAddress();
				user.setUserid(userid);
				user.setAddress(rs.getString("address"));
				user.setPost_code(rs.getString("post_code"));
				user.setBuilding(rs.getString("building"));
				regilist.add(user);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
		return regilist;
	}

	public void insert(UserAddress regi) {

		UserAddress user = new UserAddress();
		Connection con = null;
		Statement smt = null;

		//SQL文
		String sql = "INSERT INTO registered_adress VALUES('"
				+ user.getUserid() + "',	'"
				+ user.getAddress() + "','"
				+ user.getPost_code() + "','"
				+ user.getBuilding() + "')";
		try {
			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}

	}
}
