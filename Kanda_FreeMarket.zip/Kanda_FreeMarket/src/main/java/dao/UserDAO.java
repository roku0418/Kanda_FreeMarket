/*
UserのDAOクラス（メソッド：selectByUser)
作成者：出口莉菜
*/
package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.User;
import common.DBConnecter;

public class UserDAO {


	//指定ユーザーの条件に合致する情報を取得する
	public User selectByUser(String userid, String password) {

		User user = new User();
		Connection con = null;
		Statement smt = null;

		try {
			String sql = "SELECT * FROM userinfo WHERE user ='" + userid + "' AND password='" + password + "'";

			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				user.setUserid(rs.getInt("user"));
				user.setPassword(rs.getString("password"));
				user.setPassword(rs.getString("userName"));
				user.setPassword(rs.getString("nickname"));
				user.setPassword(rs.getString("address"));
				user.setEmail(rs.getString("email"));
				user.setAuthority(rs.getInt("authority"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
		return user;
	}
}
