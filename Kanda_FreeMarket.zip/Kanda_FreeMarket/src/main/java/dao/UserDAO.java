/*
UserのDAOクラス（メソッド：selectByUser)
作成者：出口莉菜
*/
package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.User;
import common.DBConnecter;

public class UserDAO {

	//指定ユーザーの条件に合致する情報を取得する
	public int insert(User user) {

		Connection con = null;
		Statement smt = null;
		int userid = 0;
		try {
			String sql = "INSERT INTO userinfo (password, handle_name, email, phone, real_name, authority) "
					+ "VALUES ('" + user.getPassword() + "','" + user.getHandle_name() + "','" + user.getEmail() + "',"
					+ user.getPhone() + ",'"
					+ user.getReal_name() + "', 2)";

			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			smt.executeUpdate(sql);

			//TODO m戻り値エラーチェック
			
			sql = "SELECT MAX(userid) as maxuserid from userinfo";
			
			ResultSet rs = smt.executeQuery(sql);
			
			if(rs.next()) {
				userid = rs.getInt("maxuserid");
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
		return userid;
	}

	//指定ユーザーの条件に合致する情報を取得する
	public User selectByUserId(int userid) {

		User user = new User();
		Connection con = null;
		Statement smt = null;

		try {
			String sql = "SELECT * FROM userinfo WHERE userid =" + userid;

			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				user.setUserid(userid);
				user.setPassword(rs.getString("password"));
				user.setHandle_name(rs.getString("handle_name"));
				user.setEmail(rs.getString("email"));
				user.setPhone(rs.getInt("phone"));
				user.setReal_name(rs.getString("real_name"));
				user.setAuthority(rs.getInt("authority"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
		return user;
	}

	public String loginCheck(String email) {
		String pass = null;
		Connection con = null;
		Statement smt = null;

		try {
			String sql = "SELECT password FROM userinfo WHERE email ='" + email + "'";

			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				pass = rs.getString("password");

			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
		return pass;
	}

	/*
	 * 管理者用のユーザーリストに必要な情報
	 */
	public ArrayList<User> getUserList() {
		User user = null;
		Connection con = null;
		Statement smt = null;

		ArrayList<User> userList = new ArrayList<User>();
		try {
			//TODO 必要なカラムだけ抜き出す
			String sql = "SELECT * FROM userinfo";

			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			//必要な情報を行数分取り出す
			while (rs.next()) {
				user = new User();
				user.setUserid(rs.getInt("userid"));
				user.setReal_name(rs.getString("real_name"));
				user.setEmail(rs.getString("email"));
				user.setPhone(rs.getInt("phone"));
				userList.add(user);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
		return userList;
	}

	//指定ユーザーの条件に合致する情報を取得する
	public User selectByemail(String email) {

		User user = null;
		Connection con = null;
		Statement smt = null;

		try {
			String sql = "SELECT * FROM userinfo WHERE email ='" + email + "'";

			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				user = new User();
				user.setUserid(rs.getInt("userid"));
				user.setPassword(rs.getString("password"));
				user.setHandle_name(rs.getString("handle_name"));
				user.setEmail(rs.getString("email"));
				user.setPhone(rs.getInt("phone"));
				user.setReal_name(rs.getString("real_name"));
				user.setAuthority(rs.getInt("authority"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
		return user;
	}
}
