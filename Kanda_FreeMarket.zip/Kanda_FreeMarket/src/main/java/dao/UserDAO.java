/*
UserのDAOクラス（メソッド：selectByUser)
作成者：出口莉菜
*/
package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.User;
import common.DBConnecter;

public class UserDAO {


	//指定ユーザーの条件に合致する情報を取得する
	public void insert(User user) {

		Connection con = null;
		Statement smt = null;

		try {
			String sql = "INSERT INTO userinfo (password, handle_name, email, phone, real_name, authority) "
					+ "VALUES ('" + user.getPassword() + "','" + user.getHandle_name() + "','" + user.getEmail() + "'," + user.getPhone() + ",'"
					+ user.getReal_name() + "', 2";

			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			smt.executeUpdate(sql);

			//TODO m戻り値エラーチェック
		
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
		
	}
	
	//指定ユーザーの条件に合致する情報を取得する
		public User selectByUserId(int userid) {

			User user = new User();
			Connection con = null;
			Statement smt = null;

			try {
				String sql = "SELECT * FROM userinfo WHERE user =" + userid;

				con = DBConnecter.get().getConnection();
				smt = con.createStatement();
				ResultSet rs = smt.executeQuery(sql);

				if (rs.next()) {
					user.setUserid(userid);
					user.setPassword(rs.getString("password"));
					user.setHandle_name(rs.getString("userName"));
					user.setEmail(rs.getString("nickname"));
					user.setPhone(rs.getInt("address"));
					user.setReal_name(rs.getString("email"));
					user.setAuthority(rs.getInt("authority"));
				}

			} catch (Exception e) {
				throw new IllegalStateException(e);
			} finally {
				if (smt != null) {
					try {
						smt.close();
					} catch (SQLException ignore) {
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException ignore) {
					}
				}

			}
			return user;
		}
		
		public String loginCheck(int userid) {
			String pass = null;
			Connection con = null;
			Statement smt = null;

			try {
				String sql = "SELECT password FROM userinfo WHERE user =" + userid;

				con = DBConnecter.get().getConnection();
				smt = con.createStatement();
				ResultSet rs = smt.executeQuery(sql);

				if (rs.next()) {
					pass = rs.getString("password");
					
				}

			} catch (Exception e) {
				throw new IllegalStateException(e);
			} finally {
				if (smt != null) {
					try {
						smt.close();
					} catch (SQLException ignore) {
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException ignore) {
					}
				}

			}
			return pass;
		}
}
