package dao;

import jakarta.servlet.http.HttpServlet;

public class RegisterDAO extends HttpServlet {

}
