package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Register;
import common.DBConnecter;

public class RegisterDAO{
	public ArrayList<Register> selectByUserId(int userid) {

		Register user;
		Connection con = null;
		Statement smt = null;
		ArrayList<Register> regilist = new ArrayList<Register>();
		try {
			String sql = "SELECT * FROM registered_address WHERE user =" + userid;

			con = DBConnecter.get().getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()) {
				user = new Register();
				user.setUserid(userid);
				user.setAddress(rs.getString("address"));
				user.setPost_code(rs.getString("post_code"));
				user.setBuilding(rs.getString("building"));
				regilist.add(user);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
		return regilist;
	}
	
	public void insert(Register regi) {
		
	}
}
