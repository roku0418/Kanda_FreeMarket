//////////////////////////////
//DB操作クラスです。
//
//制作者：加納七翔
//
//////////////////////////////
package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import bean.Taginfo;
import common.DBConnecter;
import common.Tags;

public class TagDAO{
	
	/*
	 * 
	 */
	public void insert(Taginfo taginfo, String[] select)
	{
		Connection con = null;
		Statement smt = null;
		try {
			//TODO goodsinfoに登録済みの情報かを精査するべき？
			
			//最初にすべてのタグをオフにして登録する
			//sql文生成
			String sql = "INSERT INTO taginfo (goodsid, goodsname) VALUES ('" + taginfo.getGoodsid() + "','" + taginfo.getGoodsname() + "')";
			
			con = DBConnecter.get().getConnection();
			//トランザクション処理開始
			smt = con.createStatement();
			smt.executeUpdate(sql);
			
			//updateで必要な分のタグを更新
			sql = "UPDATE taginfo SET goodsname = '" + taginfo.getGoodsname() + "'";
			
			for(int i = 0; i < select.length; i++	) {
				sql += "," + select[i] + " = 1";
			}
			
			sql += " WHERE goodsid = (SELECT MAX(goodsid) FROM taginfo)";
			
			//sql発行
			smt.executeUpdate(sql);
			//TODO 戻り値エラーチェック
			
		}
		catch (Exception e) {
			throw new IllegalStateException(e);
		} 
		finally {
			if (smt != null) {
				try {
					smt.close();
				}
				catch (SQLException ignore) {
				
				}
			}
			if (con != null) {
				try {
					con.close();
				} 
				catch (SQLException ignore) {
				
				}
			}
		}
	}
	
	public Taginfo selectByGoodsid(int goodsid){
		Connection con = null;
		Statement smt = null;
		Taginfo taginfo = new Taginfo();
		try {

			//sql文生成
			String sql = "SELECT * FROM Taginfo WHERE goodsid = " + goodsid;
			
			con = DBConnecter.get().getConnection();
			//トランザクション処理開始
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);
			
			if(rs.next()) {
				taginfo.setGoodsid(rs.getInt("goodsid"));
				taginfo.setGoodsname(rs.getString("goodsname"));
				Tags tags = new Tags(false);
				for(Map.Entry<String, Boolean> entry : tags.getMap().entrySet()) {
					if(rs.getByte(entry.getKey()) == 1) {
						tags.setTag(entry.getKey(), true);
					}
					else {
						tags.setTag(entry.getKey(), false);
					}
					
				}
				taginfo.setTags(tags);
			}
			
		}
		catch (Exception e) {
			throw new IllegalStateException(e);
		} 
		finally {
			if (smt != null) {
				try {
					smt.close();
				}
				catch (SQLException ignore) {
				
				}
			}
			if (con != null) {
				try {
					con.close();
				} 
				catch (SQLException ignore) {
				
				}
			}
		}
		return taginfo;
	}
}
