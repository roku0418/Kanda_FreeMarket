package dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Taginfo;
import common.DBConnecter;

public class TagDAO{
	
	/*
	 * 
	 */
	public void insert(Taginfo taginfo, String[] select)
	{
		Connection con = null;
		Statement smt = null;
		try {
			//TODO goodsinfoに登録済みの情報かを精査するべき？
			
			//最初にすべてのタグをオフにして登録する
			//sql文生成
			String sql = "INSERT INTO taginfo (goodsname) VALUES ('"
					+ taginfo.getGoodsname() + "'";
			
			con = DBConnecter.get().getConnection();
			//トランザクション処理開始
			smt = con.createStatement();
			smt.executeUpdate(sql);
			
			//updateで必要な分のタグを更新
			sql = "UPDATE taginfo SET goodsname = '" + taginfo.getGoodsname() + "'";
			
			for(int i = 0; i < select.length; i++	) {
				sql += "," + select[i] + " = 1";
			}
			
			sql += " WHERE goodsid = (SELECT MAX(goodsid) FROM taginfo)";
			
			//sql発行
			smt.executeUpdate(sql);
			//TODO 戻り値エラーチェック
			
		}
		catch (Exception e) {
			throw new IllegalStateException(e);
		} 
		finally {
			if (smt != null) {
				try {
					smt.close();
				}
				catch (SQLException ignore) {
				
				}
			}
			if (con != null) {
				try {
					con.close();
				} 
				catch (SQLException ignore) {
				
				}
			}
		}
	}
	
	
}
