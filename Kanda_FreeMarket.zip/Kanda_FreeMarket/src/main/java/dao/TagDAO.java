package dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Taginfo;
import common.DBConnecter;

public class TagDAO{
	
	/*
	 * 
	 */
	public void insert(Taginfo taginfo)
	{
		Connection con = null;
		Statement smt = null;
		try {
			//TODO goodsinfoに登録済みの情報かを精査するべき？
			
			//最初にすべてのタグをオンにして登録する
			//sql文生成
			String sql = "INSERT INTO taginfo (goodsname) VALUES ('"
					+ taginfo.getGoodsname() + "'";
			
			con = DBConnecter.get().getConnection();
			//トランザクション処理開始
			smt = con.createStatement();
			smt.executeUpdate(sql);
		}
		catch (Exception e) {
			throw new IllegalStateException(e);
		} 
		finally {
			if (smt != null) {
				try {
					smt.close();
				}
				catch (SQLException ignore) {
				
				}
			}
			if (con != null) {
				try {
					con.close();
				} 
				catch (SQLException ignore) {
				
				}
			}
		}
	}
	
	
}
