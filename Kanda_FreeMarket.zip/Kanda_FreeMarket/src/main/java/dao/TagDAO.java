package dao;

import jakarta.servlet.http.HttpServlet;

public class TagDAO extends HttpServlet {

}
