package dao;

import java.awt.print.Book;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Goods;
import bean.Search;
import common.DBConnecter;

public class GoodsDAO{

	public Goods selectByGoodsID(String goodsid) {

		Connection con = null;
		Statement smt = null;
		//①検索した書籍情報を格納するBookオブジェクトを生成します。
		Goods goods = new Goods();

		try {
			//②引数の情報を利用し、検索用のSQL文を文字列として定義します。※SQL文は設計書参照
			String sql = "SELECT * FROM goodsinfo WHERE goodsid = '" + goodsid + "'";

			// ③BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成します。
			con = DBConnecter.get().getConnection();

			//  ④ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成します。
			smt = con.createStatement();

			//  ⑤Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得します。
			ResultSet rs = smt.executeQuery(sql);

			//  ⑥結果セットから書籍データを取り出し、Bookオブジェクトに格納します。
			if (rs.next()) {

				goods.setImage(rs.getString("image"));
				goods.setGoodsid(rs.getString("goodsid"));
				goods.setGoodsname(rs.getString("goodsname"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				goods.setSeller(rs.getString("seller"));
				goods.setSell_date(rs.getString("sell_date"));
				goods.setUpdate_date(rs.getString("update_date"));
				goods.setComment(rs.getString("comment"));
				goods.setGoods_status(rs.getInt("goods_status"));
				goods.setTrade_status(rs.getInt("trade_status"));
				goods.setTrader(rs.getString("trader"));
				goods.setSold_date(rs.getString("sold_date"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					//  ⑦Statementオブジェクトをクローズします。
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					//  ⑧Connectionオブジェクトをクローズします。
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return goods;
	}

	public ArrayList<Goods> selectAll() {
		Connection con = null;
		Statement smt = null;

		//検索した書籍情報を格納するAllayListオブジェクトを生成
		ArrayList<Goods> goodsList = new ArrayList<Goods>();

		try {
			//SQL文を文字列として定義
			String sql = "SELECT * FROM bookinfo ORDER BY goodsid";
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//Statementオブジェクトの、executeQuery（）メソッドを利用して、SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);
			//結果セットから書籍データを検索件数分全て取り出し、AllayListオブジェクトにBookオブジェクトとして格納
			while (rs.next()) {
				Goods goods = new Goods();
				goods.setImage(rs.getString("image"));
				goods.setGoodsid(rs.getString("goodsid"));
				goods.setGoodsname(rs.getString("goodsname"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				goods.setSeller(rs.getString("seller"));
				goods.setSell_date(rs.getString("sell_date"));
				goods.setUpdate_date(rs.getString("update_date"));
				goods.setComment(rs.getString("comment"));
				goods.setGoods_status(rs.getInt("goods_status"));
				goods.setTrade_status(rs.getInt("trade_status"));
				goods.setTrader(rs.getString("trader"));
				goods.setSold_date(rs.getString("sold_date"));
				goodsList.add(goods);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//	Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return goodsList;
	}

	/*サーチメソッド（引数：商品名）
	 *→商品名、Goodsid、画像のファイル名、取引状態（管理者）を戻り値 
	*/
	public ArrayList<Search> searchByAdimin(String goodsid) {

		Connection con = null;
		Statement smt = null;

		//検索した書籍情報を格納するAllayListオブジェクトを生成
		ArrayList<Search> adminlist = new ArrayList<>();

		try {
			//SQL文を文字列として定義
			String sql = "SELECT image,goodsid, goodsname, trade_status FROM bookinfo " +
					"WHERE isbn LIKE '%" + goodsid + "%'";
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);
			//結果セットから書籍データを検索件数分全て取り出し、AllayListオブジェクトにBookオブジェクトとして格納
			while (rs.next()) {
				Search search = new Search();
				search.setImage(rs.getString("image"));
				search.setImage(rs.getString(""));
				search.setImage(rs.getString("image"));
				search.setImage(rs.getString("image"));
				adminlist.add(search);

			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズします。
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//Connectionオブジェクトをクローズします。
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return adminlist;
	}

	/*サーチメソッド（引数：商品名）
	 *→商品名、Goodsid、画像のファイル名、を戻り値 
	*/
	public ArrayList<Goods> searchByUser(String isbn, String title, String price) {

		Connection con = null;
		Statement smt = null;

		//検索した書籍情報を格納するAllayListオブジェクトを生成
		ArrayList<Goods> List = new ArrayList<Goods>();

		try {
			//SQL文を文字列として定義
			String sql = "SELECT isbn,title,price FROM bookinfo " +
					"WHERE isbn LIKE '%" + isbn + "%' AND title LIKE '%"
					+ title + "%' AND price LIKE '%" + price + "%'";
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);
			//結果セットから書籍データを検索件数分全て取り出し、AllayListオブジェクトにBookオブジェクトとして格納
			while (rs.next()) {
				Book book = new Book();
//				book.setIsbn(rs.getString("isbn"));
//				book.setPrice(rs.getInt("price"));
//				book.setTitle(rs.getString("title"));
				//List.add(book);

			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズします。
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//Connectionオブジェクトをクローズします。
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return List;
	}

	/*
	メソッド名	:	insert
	戻り値	:	なし
	引数	:	登録する書籍データを格納したBookオブジェクト
	 */
	public void insert(Book book) {

		Connection con = null;
		Statement smt = null;

		try {

			//①引数の情報を利用し、登録用のSQL文を文字列として定義
//			String sql = "INSERT INTO bookinfo VALUES('" + book.getIsbn() + "','" + book.getTitle() + "',"
//					+ book.getPrice() + ")";

			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成。
			con = DBConnecter.get().getConnection();

			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			//Statementオブジェクトの、executeUpdate（）メソッドを利用して、①のSQL文を発行し書籍データを登録
			//int rowsCount = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				//Connectionオブジェクトをクローズ
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	//update(Book book) : void
	public void update(Book book) {

		Connection con = null;
		Statement smt = null;

		try {
			//②引数の情報を利用し、検索用のSQL文を文字列として定義します。※SQL文は設計書参照
//			String sql = "UPDATE bookinfo SET title='" + book.getTitle() + "',price=" + book.getPrice()
//					+ " WHERE isbn='" + book.getIsbn() + "'";

			// ③BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成します。
			con = DBConnecter.get().getConnection();

			//  ④ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成します。
			smt = con.createStatement();

			//  ⑤Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得します。
			//smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					//  ⑦Statementオブジェクトをクローズします。
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					//  ⑧Connectionオブジェクトをクローズします。
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	//delete(Strinｇ isbn) : void
	public void delete(int id) {

		Connection con = null;
		Statement smt = null;

		try {
			//②引数の情報を利用し、検索用のSQL文を文字列として定義します。※SQL文は設計書参照
			String sql = "DELETE FROM goodsinfo WHERE isbn = '" + id + "'";

			// ③BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成します。
			con = DBConnecter.get().getConnection();

			//  ④ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成します。
			smt = con.createStatement();

			//  ⑤Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得します。
			smt.executeUpdate(sql);
			//TODO 戻り値エラーチェック↑
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					//  ⑦Statementオブジェクトをクローズします。
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					//  ⑧Connectionオブジェクトをクローズします。
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}

	}

}
