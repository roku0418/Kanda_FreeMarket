//////////////////////////////
//DB操作クラスです。
//
//制作者：加納七翔
//
//////////////////////////////
package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import bean.Goods;
import common.DBConnecter;
import common.Tags;

public class GoodsDAO {

	public Goods selectByGoodsID(int goodsid) {

		Connection con = null;
		Statement smt = null;
		//①検索した書籍情報を格納するBookオブジェクトを生成します。
		Goods goods = new Goods();

		try {
			//②引数の情報を利用し、検索用のSQL文を文字列として定義します。※SQL文は設計書参照
			String sql = "SELECT * FROM goodsinfo WHERE goodsid = '" + goodsid + "'";

			// ③BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成します。
			con = DBConnecter.get().getConnection();

			//  ④ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成します。
			smt = con.createStatement();

			//  ⑤Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得します。
			ResultSet rs = smt.executeQuery(sql);

			//  ⑥結果セットから書籍データを取り出し、Bookオブジェクトに格納します。
			if (rs.next()) {

				goods.setImage(rs.getString("image"));
				goods.setGoodsid(rs.getInt("goodsid"));
				goods.setGoodsname(rs.getString("goodsname"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				goods.setSeller(rs.getInt("seller"));
				goods.setSell_date(rs.getString("sell_date"));
				goods.setUpdate_date(rs.getString("update_date"));
				goods.setComment(rs.getString("comment"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				//goods.setGoods_status(rs.getInt("goods_status"));
				goods.setTrade_status(rs.getInt("trade_status"));
				goods.setTrader(rs.getString("trader"));
				goods.setSold_date(rs.getString("sold_date"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					//  ⑦Statementオブジェクトをクローズします。
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					//  ⑧Connectionオブジェクトをクローズします。
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return goods;
	}

	public ArrayList<Goods> selectAll() {
		Connection con = null;
		Statement smt = null;

		//検索した書籍情報を格納するAllayListオブジェクトを生成
		ArrayList<Goods> goodsList = new ArrayList<Goods>();

		try {
			//SQL文を文字列として定義
			String sql = "SELECT * FROM goodsinfo ORDER BY goodsid";
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//Statementオブジェクトの、executeQuery（）メソッドを利用して、SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);
			//結果セットから書籍データを検索件数分全て取り出し、AllayListオブジェクトにBookオブジェクトとして格納
			while (rs.next()) {
				Goods goods = new Goods();
				goods.setGoodsid(rs.getInt("goodsid"));
				goods.setGoodsname(rs.getString("goodsname"));
				goods.setImage(rs.getString("image"));
				goods.setTrade_status(rs.getInt("trade_status"));
				goods.setSeller(rs.getInt("seller"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				goodsList.add(goods);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//	Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return goodsList;
	}

	/*サーチメソッド（引数：商品名）
	 *→商品名、Goodsid、画像のファイル名、取引状態（管理者）を戻り値 
	*/
	public ArrayList<Goods> search(String goodsname, Tags tags) {

		Connection con = null;
		Statement smt = null;

		//検索した書籍情報を格納するAllayListオブジェクトを生成
		ArrayList<Goods> list = new ArrayList<>();

		try {
			//SQL文を文字列として定義
			String sql;
			if (goodsname != null && "".equals(goodsname) != true) {
				sql = "SELECT goodsid FROM taginfo " +
						"WHERE goodsname LIKE '%" + goodsname + "%'";
			} else {
				sql = "SELECT goodsid FROM taginfo " +
						"WHERE 1 = 1";
			}

			if (tags != null) {
				//タグ検索
				for (Map.Entry<String, Boolean> entry : tags.getMap().entrySet()) {
					if (entry.getValue() == true) {
						sql += " AND " + entry.getKey() + " = 1";
					}
				}

			}

			ArrayList<Integer> ids = new ArrayList<Integer>();
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);
			//結果セットから書籍データを検索件数分全て取り出し、AllayListオブジェクトにBookオブジェクトとして格納
			while (rs.next()) {
				ids.add(rs.getInt("goodsid"));
			}

			sql = "SELECT goodsid, goodsname, trade_status, image, goodsprice FROM goodsinfo ";

			if (ids.size() != 0) {
				sql += "WHERE false";
				for (var i : ids) {
					sql += " OR goodsid=" + i;
				}
			}

			rs = smt.executeQuery(sql);

			while (rs.next()) {
				Goods goods = new Goods();
				goods.setGoodsid(rs.getInt("goodsid"));
				goods.setGoodsname(rs.getString("goodsname"));
				goods.setImage(rs.getString("image"));
				goods.setTrade_status(rs.getInt("trade_status"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				list.add(goods);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズします。
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//Connectionオブジェクトをクローズします。
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}

	public ArrayList<Goods> selectAllOfAdmin() {

		Connection con = null;
		Statement smt = null;

		//検索した書籍情報を格納するAllayListオブジェクトを生成
		ArrayList<Goods> list = new ArrayList<>();

		try {

			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			String sql = "SELECT goodsid, goodsname, trade_status, image, goodsprice FROM goodsinfo";

			//Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Goods goods = new Goods();
				goods.setGoodsid(rs.getInt("goodsid"));
				goods.setGoodsname(rs.getString("goodsname"));
				goods.setImage(rs.getString("image"));
				goods.setTrade_status(rs.getInt("trade_status"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				list.add(goods);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズします。
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//Connectionオブジェクトをクローズします。
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}

	public int insert(Goods goods, int userid) {

		Connection con = null;
		Statement smt = null;
		int returnint = 0;
		try {

			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			String sql = "INSERT INTO goodsinfo (image, goodsid, goodsname, goodsprice, seller, sell_date,comment, trader,trade_status)"
					+ " VALUES ('" + goods.getImage() + "','" + goods.getGoodsid() + "','" + goods.getGoodsname()
					+ "','" + goods.getGoodsprice() + "',"
					+ "'" + goods.getSeller() + "',CURRENT_TIMESTAMP,'" + goods.getComment() + "','" + goods.getTrader()
					+ "', 1)";

			//Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得
			int cnt = smt.executeUpdate(sql);

			sql = "SELECT MAX(goodsid) as maxgoodsid FROM goodsinfo";
			ResultSet rs = smt.executeQuery(sql);
			if (rs.next()) {
				returnint = rs.getInt("maxgoodsid");
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズします。
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//Connectionオブジェクトをクローズします。
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return returnint;
	}

	public void setTradeStatus(int goodsid, int state) {
		Connection con = null;
		Statement smt = null;

		try {

			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			String sql = "UPDATE goodsinfo SET trade_status = " + state + " WHERE goodsid = " + goodsid;

			//Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得
			int cnt = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズします。
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//Connectionオブジェクトをクローズします。
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public void setTrader(int goodsid, int buyerid) {
		Connection con = null;
		Statement smt = null;

		try {

			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			String sql = "UPDATE goodsinfo SET trader = " + buyerid + " WHERE goodsid = " + goodsid;

			//Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得
			int cnt = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズします。
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//Connectionオブジェクトをクローズします。
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public ArrayList<Goods> benefitSelectAll() {
		Connection con = null;
		Statement smt = null;

		//検索した書籍情報を格納するAllayListオブジェクトを生成
		ArrayList<Goods> goodsList = new ArrayList<Goods>();

		try {
			//SQL文を文字列として定義
			String sql = "SELECT * FROM goodsinfo";
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//Statementオブジェクトの、executeQuery（）メソッドを利用して、SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);
			//結果セットから書籍データを検索件数分全て取り出し、AllayListオブジェクトにBookオブジェクトとして格納
			while (rs.next()) {
				Goods goods = new Goods();
				goods.setSeller(rs.getInt("seller"));
				goods.setTrader(rs.getString("trader"));
				goods.setGoodsname(rs.getString("goodsname"));
				goods.setImage(rs.getString("image"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				goodsList.add(goods);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//	Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return goodsList;
	}

	//購入履歴取得
	public ArrayList<Goods> getBuyHistory(int userid) {
		Connection con = null;
		Statement smt = null;
		Goods goods = null;
		//検索した書籍情報を格納するAllayListオブジェクトを生成
		ArrayList<Goods> goodsList = new ArrayList<Goods>();

		try {
			//SQL文を文字列として定義
			String sql = "SELECT * FROM goodsinfo WHERE trader = " + userid;
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//Statementオブジェクトの、executeQuery（）メソッドを利用して、SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);
			//結果セットから書籍データを検索件数分全て取り出し、AllayListオブジェクトにBookオブジェクトとして格納
			while (rs.next()) {
				goods = new Goods();
				goods.setImage(rs.getString("image"));
				goods.setGoodsid(rs.getInt("goodsid"));
				goods.setGoodsname(rs.getString("goodsname"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				goods.setSeller(rs.getInt("seller"));
				goods.setSell_date(rs.getString("sell_date"));
				goods.setUpdate_date(rs.getString("update_date"));
				goods.setComment(rs.getString("comment"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				//goods.setGoods_status(rs.getInt("goods_status"));
				goods.setTrade_status(rs.getInt("trade_status"));
				goods.setTrader(rs.getString("trader"));
				goods.setSold_date(rs.getString("sold_date"));
				goodsList.add(goods);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//	Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return goodsList;
	}

	//出品履歴
	public ArrayList<Goods> getListingHistory(int userid) {
		Connection con = null;
		Statement smt = null;
		Goods goods = null;
		//検索した書籍情報を格納するAllayListオブジェクトを生成
		ArrayList<Goods> goodsList = new ArrayList<Goods>();

		try {
			//SQL文を文字列として定義
			String sql = "SELECT * FROM goodsinfo WHERE seller = " + userid;
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = DBConnecter.get().getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//Statementオブジェクトの、executeQuery（）メソッドを利用して、SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);
			//結果セットから書籍データを検索件数分全て取り出し、AllayListオブジェクトにBookオブジェクトとして格納
			while (rs.next()) {
				goods = new Goods();
				goods.setImage(rs.getString("image"));
				goods.setGoodsid(rs.getInt("goodsid"));
				goods.setGoodsname(rs.getString("goodsname"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				goods.setSeller(rs.getInt("seller"));
				goods.setSell_date(rs.getString("sell_date"));
				goods.setUpdate_date(rs.getString("update_date"));
				goods.setComment(rs.getString("comment"));
				goods.setGoodsprice(rs.getInt("goodsprice"));
				//goods.setGoods_status(rs.getInt("goods_status"));
				goods.setTrade_status(rs.getInt("trade_status"));
				goods.setTrader(rs.getString("trader"));
				goods.setSold_date(rs.getString("sold_date"));
				goodsList.add(goods);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			//	Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return goodsList;
	}
}
