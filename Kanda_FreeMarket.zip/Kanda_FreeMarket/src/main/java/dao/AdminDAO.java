package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class AdminDAO {
	//データベース接続情報
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/mybookdb";
	private static String USER = "root";
	private static String PASS = "root123";

	private static Connection getConnection() {

		try {
			//Class.forNameメソッドを利用してJDBCドライバーをロード
			Class.forName(RDB_DRIVE);
			//DriverManager.getConnectionメソッドを利用してConnectionオブジェクトを生成
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			//生成されたConnectionオブジェクトをリターン
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

}
